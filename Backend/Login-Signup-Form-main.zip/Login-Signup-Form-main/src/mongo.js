const mongoose = require("mongoose");

mongoose.connect("mongodb://127.0.0.1:27017/EdigniteLogIn") // localhost:27017
.then(()=>{
    console.log("mongodb connected");
})
.catch(()=>{
    console.log("Mongodb not connected");
})

const loginSchema = new mongoose.Schema({
    name : {
        type : String,
        required : true
    },
    password : {
        type : String,
        required : true
    },
    email : {
        type : String,
        required : true
    }
});

const collection = new mongoose.model("IdPassword", loginSchema);
module.exports = collection;